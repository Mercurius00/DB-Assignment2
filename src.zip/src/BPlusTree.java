import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class BPlusTree<K extends Comparable<K>, V> {

	/** Pointer to the root node. It may be a leaf or an inner node, but it is never null. */
	private Node<K> root;

	String heapFilePath;
	RowData.Field indexField;
	RandomAccessFile indexFile;
	int fpOffset;
	int overflowPageOffset;
	int overflowPageLimit;
	
	public BPlusTree() {
	}

	public BPlusTree(String heapFilePath, RowData.Field indexField, String rw) {
		if (rw.equals("w")) {
			this.heapFilePath = heapFilePath;
			this.indexField = indexField;
			// open file channel
			try {
				String indexFileName = heapFilePath + "." + indexField.name();
				fpOffset = 4;
				this.root = new LNode<K, V>();
				File file = new File(indexFileName);
				if (file.exists()) {
					file.delete();
				}
				indexFile = new RandomAccessFile(indexFileName, "rw");
				indexFile.write(ByteUtil.intToByteArray(root.startPosition), 0, 4);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			this.heapFilePath = heapFilePath;
			this.indexField = indexField;
			// open file channel
			try {
				String indexFileName = heapFilePath + "." + indexField.name();
				if (!new File(indexFileName).exists()) {
					throw new RuntimeException("please add index for field");
				}
				byte[] bytes = new byte[4];
				this.indexFile = new RandomAccessFile(indexFileName, "r");
				this.indexFile.read(bytes);
				int rootPosition = ByteUtil.getIntValue(bytes, 0);
				this.root = new LNode().readNode(rootPosition);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Insert a new key and its associated value into the B+ tree.
	 */
	public void insert(K key, V value) {
		LNode<K, V> leaf = this.findLeafNodeShouldContainKey(key);
		leaf.insertKey(key, value);

		leaf.writeNode();
		
		if (leaf.isOverflow()) {
			Node<K> n = leaf.dealOverflow();
			if (n != null) {
				this.root = n;
				try {
					indexFile.seek(0);
					indexFile.write(ByteUtil.intToByteArray(root.startPosition), 0, 4);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	/**
	 * Search a key value on the tree and return its associated value.
	 */
	public List<V> find(K key) {
		LNode<K, V> leaf = this.findLeafNodeShouldContainKey(key);
		
		int index = leaf.getValue(key);
		if (index == -1) {
			return Collections.emptyList();
		}
		List<V> result = new LinkedList<>();
		result.add(leaf.getValue(index));

		int overflowPointer = leaf.getNextLink(index);
		try {
			while (overflowPointer > 0) {
				indexFile.seek(overflowPointer);
				byte[] bytes = new byte[12];
				indexFile.read(bytes);
				int pageNo = ByteUtil.getIntValue(bytes, 0);
				int recordOffset = ByteUtil.getIntValue(bytes, 4);
				result.add((V) new TreeValue(pageNo, recordOffset));
				overflowPointer = ByteUtil.getIntValue(bytes, 8);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * Search the leaf node which should contain the specified key
	 */
	@SuppressWarnings("unchecked")
	private LNode<K, V> findLeafNodeShouldContainKey(K key) {
		Node<K> node = this.root;
		while (node.getNodeType() == TreeNodeType.INODE) {
			node = ((INode<K>)node).getChild( node.getValue(key) );
		}

		if (node.keyCount == 0) {
			return (LNode<K, V>)node;
		}
		return (LNode<K, V>) ((LNode<K, V>)node).readNode(node.startPosition);
	}

	abstract class Node<K extends Comparable<K>> {

		// node head byte count
		protected static final int HEAD_LENGTH = 28;
//		protected BPlusTree bPlusTree;
		protected Object[] keys;
		protected int keyCount;

		// parent node offset
		protected int parentNode;
		// left sibling offset
		protected int leftNode;
		// right sibling offset
		protected int rightNode;
		// node offset relative to the start of index file, based from 0
		protected int startPosition;
		// node byte count
		protected int byteCount;

		protected Node() {
			this.keyCount = 0;
			this.parentNode = 0;
			this.leftNode = 0;
			this.rightNode = 0;
		}

		public int getKeyCount() {
			return this.keyCount;
		}

		@SuppressWarnings("unchecked")
		public K getKey(int index) {
			return (K)this.keys[index];
		}

		public void setKey(int index, K key) {
			this.keys[index] = key;
		}

		public abstract int getValue(K key);

		public int getParent() {
			return this.parentNode;
		}

		public void setParent(int parent) {
			this.parentNode = parent;
		}

		public abstract TreeNodeType getNodeType();

		public boolean isOverflow() {
			return this.getKeyCount() == this.keys.length;
		}

		public Node<K> dealOverflow() {
			int midIndex = this.getKeyCount() / 2;
			K upKey = this.getKey(midIndex);

			Node<K> newRNode = this.split();

			if (this.getParent() == 0) {
				Node<K> parentNode = new INode<K>();
				parentNode.writeNode();
				this.setParent(parentNode.startPosition);
			}
			this.writeNode();
			newRNode.setParent(this.getParent());

			// maintain links of sibling nodes
			newRNode.setLeftNode(this.startPosition);
			newRNode.setRightNode(this.rightNode);
			newRNode.writeNode();
			Node<K> rightSibling = this.getRightNode();
			if (rightSibling != null) {
				rightSibling.setLeftNode(newRNode.startPosition);
				rightSibling.writeNode();
			}
			this.setRightNode(newRNode.startPosition);
			this.writeNode();

			// push up a key to parent internal node
			Node<K> parentNode = readNode(this.getParent());
			parentNode = parentNode.pushUpKey(upKey, this, newRNode);
			return parentNode;
		}

		protected abstract Node<K> split();

		protected abstract Node<K> pushUpKey(K key, Node<K> leftChild, Node<K> rightNode);

		protected abstract void writeNode();

		protected void serializeTreeNodeHead(byte[] nodeBytes) {
			ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(this.startPosition), 0);
			ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(this.byteCount), 4);
			ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(this.getNodeType().ordinal()), 8);
			ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(this.getKeyCount()), 12);
			if (this.getParent() != 0) {
				ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(this.getParent()), 16);
			}
			if (this.getLeftNode() != null) {
				ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(this.getLeftNode().startPosition), 20);
			}
			if (this.getRightNode() != null) {
				ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(this.getRightNode().startPosition), 24);
			}
		}

		// deserialize node bytes to a tree node entity
		protected Node<K> readNode(int position) {
			try {
				indexFile.seek(position + 4);
				byte[] bytes = new byte[4];
				indexFile.read(bytes);
				int nodeSize = ByteUtil.getIntValue(bytes, 0);

				indexFile.seek(position);
				byte[] nodeBytes = new byte[nodeSize];
				indexFile.read(nodeBytes);
				// node type
				TreeNodeType treeNodeType = TreeNodeType.of(ByteUtil.getIntValue(nodeBytes, 8));
				int offset = HEAD_LENGTH;
				switch (treeNodeType) {
					case INODE:
						INode iNode = new INode(
								ByteUtil.getIntValue(nodeBytes, 0),
								ByteUtil.getIntValue(nodeBytes, 4),
								ByteUtil.getIntValue(nodeBytes, 12),
								ByteUtil.getIntValue(nodeBytes, 16),
								ByteUtil.getIntValue(nodeBytes, 20),
								ByteUtil.getIntValue(nodeBytes, 24));
						for (int i = 0; i < (INode.M + 1); i++) {
							if (indexField.type() == Integer.class) {
								int key = ByteUtil.getIntValue(nodeBytes, offset);
								if (key > 0) {
									iNode.keys[i] = key;
								}
								offset += 4;
							} else {
								String key = ByteUtil.getStringValue(nodeBytes, offset, indexField.length).trim();
								if (key != null && !key.equals("")) {
									iNode.keys[i] = key;
								}
								offset += indexField.length;
							}
						}
						for (int i = 0; i < (INode.M + 2); i++) {
							int child = ByteUtil.getIntValue(nodeBytes, offset);
							if (child > 0) {
								iNode.children[i] = child;
							}
							offset += 4;
						}
						return iNode;
					case LNODE:
						LNode lNode = new LNode(
								ByteUtil.getIntValue(nodeBytes, 0),
								ByteUtil.getIntValue(nodeBytes, 4),
								ByteUtil.getIntValue(nodeBytes, 12),
								ByteUtil.getIntValue(nodeBytes, 16),
								ByteUtil.getIntValue(nodeBytes, 20),
								ByteUtil.getIntValue(nodeBytes, 24));
						for (int i = 0; i < (LNode.KEY_COUNT + 1); i++) {
							if (indexField.type() == Integer.class) {
								int key = ByteUtil.getIntValue(nodeBytes, offset);
								if (key > 0) {
									lNode.keys[i] = key;
								}
								offset += 4;
							} else {
								String key = ByteUtil.getStringValue(nodeBytes, offset, indexField.length).trim();
								if (key != null && !key.equals("")) {
									lNode.keys[i] = key;
								}
								offset += indexField.length;
							}
						}
						for (int i = 0; i < (LNode.KEY_COUNT + 1); i++) {

							int pageNo = ByteUtil.getIntValue(nodeBytes, offset);
							if (pageNo > 0) {
								offset += 4;
								int recordNumber = ByteUtil.getIntValue(nodeBytes, offset);
								offset += 4;
								TreeValue address = new TreeValue(pageNo, recordNumber);
								lNode.setValue(i, address);

								int overflowPointer = ByteUtil.getIntValue(nodeBytes, offset);
								offset += 4;
								int overflowTail = ByteUtil.getIntValue(nodeBytes, offset);
								offset += 4;
								lNode.setNextData(i, overflowPointer);
								lNode.setTail(i, overflowTail);
							} else {
								offset += 16;
							}
						}
						return lNode;
					default:
						throw new RuntimeException("unsupported node");
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			return null;
		}

		public Node<K> getLeftNode() {
			if (this.leftNode != 0) {
				Node<K> leftSibling = readNode(this.leftNode);
				if (leftSibling.getParent() == this.getParent()) {
					return leftSibling;
				}
			}
			return null;
		}

		public void setLeftNode(int sibling) {
			this.leftNode = sibling;
		}

		public Node<K> getRightNode() {
			if (this.rightNode != 0) {
				Node<K> rightSibling = readNode(this.rightNode);
				if (rightSibling.getParent() == this.getParent()) {
					return rightSibling;
				}
			}
			return null;
		}

		public void setRightNode(int silbling) {
			this.rightNode = silbling;
		}
	}

	enum TreeNodeType {
		INODE,
		LNODE;

		public static TreeNodeType of(int ordinal) {
			for (TreeNodeType value : TreeNodeType.values()) {
				if (value.ordinal() == ordinal) {
					return value;
				}
			}
			return null;
		}
	}

	class INode<K extends Comparable<K>> extends Node<K> {

		// the capacity of nodes
		protected final static int M = 4;
		protected int[] children;

		public INode() {
			this.keys = new Object[M + 1];
			this.children = new int[M + 2];

			byteCount = HEAD_LENGTH + (M + 1) * indexField.length + (M + 2) * 4;
			startPosition = fpOffset;
			fpOffset += byteCount;
		}

		public INode(int position, int size, int keyCount, int parent, int left, int right) {
			this.keys = new Object[M + 1];
			this.children = new int[M + 2];

			this.startPosition = position;
			this.byteCount = size;
			this.keyCount = keyCount;
			this.parentNode = parent;
			this.leftNode = left;
			this.rightNode = right;
		}

		@SuppressWarnings("unchecked")
		public Node<K> getChild(int index) {
			int offset = this.children[index];
			if (offset == 0) {
				return null;
			}
			return (Node<K>) readNode(offset);
		}

		public void setChild(int index, Node<K> child) {
			if (child != null) {
				this.children[index] = child.startPosition;

				child.setParent(this.startPosition);
				child.writeNode();
			} else {
				this.children[index] = 0;
			}
		}

		@Override
		public TreeNodeType getNodeType() {
			return TreeNodeType.INODE;
		}

		@Override
		public int getValue(K key) {
			int index = 0;
			for (index = 0; index < this.getKeyCount(); ++index) {
				int cmp = this.getKey(index).compareTo(key);
				if (cmp == 0) {
					return index + 1;
				}
				else if (cmp > 0) {
					return index;
				}
			}

			return index;
		}


		private void insertAt(int index, K key, Node<K> leftChild, Node<K> rightChild) {
			// move space for the new key
			for (int i = this.getKeyCount() + 1; i > index; --i) {
				this.setChild(i, this.getChild(i - 1));
			}
			for (int i = this.getKeyCount(); i > index; --i) {
				this.setKey(i, this.getKey(i - 1));
			}

			// insert the new key
			this.setKey(index, key);
			this.setChild(index, leftChild);
			this.setChild(index + 1, rightChild);
			this.keyCount += 1;
			writeNode();
		}

		/**
		 * When splits a internal node, the middle key is kicked out and be pushed to parent node.
		 */
		@Override
		protected Node<K> split() {
			int midIndex = this.getKeyCount() / 2;

			INode<K> newRNode = new INode<K>();
			for (int i = midIndex + 1; i < this.getKeyCount(); ++i) {
				newRNode.setKey(i - midIndex - 1, this.getKey(i));
				this.setKey(i, null);
			}
			for (int i = midIndex + 1; i <= this.getKeyCount(); ++i) {
				newRNode.setChild(i - midIndex - 1, this.getChild(i));
				Node<K> child = newRNode.getChild(i - midIndex - 1);
				child.setParent(newRNode.startPosition);
				child.writeNode();
				this.setChild(i, null);
			}
			this.setKey(midIndex, null);
			newRNode.keyCount = this.getKeyCount() - midIndex - 1;
			this.keyCount = midIndex;

			newRNode.writeNode();
			writeNode();
			return newRNode;
		}

		@Override
		protected Node<K> pushUpKey(K key, Node<K> leftChild, Node<K> rightNode) {
			// find the target position of the new key
			int index = this.getValue(key);

			// insert the new key
			this.insertAt(index, key, leftChild, rightNode);

			// check whether current node need to be split
			if (this.isOverflow()) {
				return this.dealOverflow();
			}
			else {
				return this.getParent() == 0 ? this : null;
			}
		}

		@Override
		protected void writeNode() {

			byte[] nodeBytes = new byte[byteCount];
			serializeTreeNodeHead(nodeBytes);
			int nodeDataOffset = HEAD_LENGTH;
			for (int i = 0; i < this.keys.length; i++) {
				if (this.getKey(i) != null) {
					if (indexField.type() == Integer.class) {
						ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(Integer.valueOf(this.getKey(i).toString())), nodeDataOffset);
					} else {
						ByteUtil.setArrayData(nodeBytes, this.getKey(i).toString().getBytes(), nodeDataOffset);
					}
				}
				nodeDataOffset += indexField.length;
			}
			for (int i = 0; i < children.length; i++) {
				ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(children[i]), nodeDataOffset);
				nodeDataOffset += 4;
			}
			try {
				indexFile.seek(this.startPosition);
				indexFile.write(nodeBytes, 0, nodeBytes.length);
			} catch (IOException e) {
				System.err.println("write b+tree node into index file failed");
				e.printStackTrace();
			}
		}
	}

	class LNode<K extends Comparable<K>, V> extends Node<K> {

		// when key count is above KEY_COUNT, split this node
		protected final static int KEY_COUNT = 4;
		private Object[] values;
		private int[] next;
		private int[] tail;

		public LNode() {
			this.keys = new Object[KEY_COUNT + 1];
			this.values = new Object[KEY_COUNT + 1];
			this.next = new int[KEY_COUNT + 1];
			this.tail = new int[KEY_COUNT + 1];

			byteCount = HEAD_LENGTH + (KEY_COUNT + 1) * (indexField.length + 16);
			startPosition = fpOffset;
			fpOffset += byteCount;
		}

		public LNode(int position, int size, int keyCount, int parent, int left, int right) {
			this.keys = new Object[KEY_COUNT + 1];
			this.values = new Object[KEY_COUNT + 1];

			this.next = new int[KEY_COUNT + 1];
			this.tail = new int[KEY_COUNT + 1];

			this.startPosition = position;
			this.byteCount = size;
			this.keyCount = keyCount;
			this.parentNode = parent;
			this.leftNode = left;
			this.rightNode = right;
		}

		public Object[] getValues() {
			return values;
		}

		@SuppressWarnings("unchecked")
		public V getValue(int index) {
			return (V) this.values[index];
		}

		public int getNextLink(int index) {
			return next[index];
		}

		public int getLinkTail(int index) {
			return tail[index];
		}

		public void setNextData(int index, int nextDataOffset) {
			next[index] = nextDataOffset;
		}

		public void setTail(int index, int overflowTail) {
			tail[index] = overflowTail;
		}

		public void setValue(int index, V value) {
			this.values[index] = value;
		}

		@Override
		public TreeNodeType getNodeType() {
			return TreeNodeType.LNODE;
		}

		@Override
		public int getValue(K key) {
			for (int i = 0; i < this.getKeyCount(); ++i) {
				 int cmp = this.getKey(i).compareTo(key);
				 if (cmp == 0) {
					 return i;
				 }
				 else if (cmp > 0) {
					 return -1;
				 }
			}

			return -1;
		}


		public void insertKey(K key, V value) {
			int index = 0;
			while (index < this.getKeyCount() && this.getKey(index).compareTo(key) < 0)
				++index;
			this.insertAt(index, key, value);
		}

		private void insertAt(int index, K key, V value) {

			if (keys[index] != null && keys[index].equals(key)) {
				// key exists, update it
				// replace value of key
				this.setKey(index, key);
				this.setValue(index, value);
			} else {
				// key not exists, add a new nodekey not exists, add a new node

				// move space for the new key
				for (int i = this.getKeyCount() - 1; i >= index; --i) {
					this.setKey(i + 1, this.getKey(i));
					this.setValue(i + 1, this.getValue(i));
					this.setNextData(i + 1, this.getNextLink(i));
					this.setTail(i + 1, this.getLinkTail(i));
				}

				// insert new key and value
				this.setKey(index, key);
				this.setValue(index, value);
				this.setNextData(index, 0);
				this.setTail(index, 0);
				++this.keyCount;
			}
		}


		// When splits a leaf node, the middle key is kept on new node and be pushed to parent node.
		@Override
		protected Node<K> split() {
			int midIndex = this.getKeyCount() / 2;

			LNode<K, V> newRNode = new LNode<K, V>();
			for (int i = midIndex; i < this.getKeyCount(); ++i) {
				newRNode.setKey(i - midIndex, this.getKey(i));
				newRNode.setValue(i - midIndex, this.getValue(i));
				newRNode.setNextData(i - midIndex, this.getNextLink(i));
				newRNode.setTail(i - midIndex, this.getLinkTail(i));
				this.setKey(i, null);
				this.setValue(i, null);
				this.setNextData(i, 0);
				this.setTail(i, 0);
			}
			newRNode.keyCount = this.getKeyCount() - midIndex;
			this.keyCount = midIndex;

			return newRNode;
		}

		@Override
		protected Node<K> pushUpKey(K key, Node<K> leftChild, Node<K> rightNode) {
			throw new UnsupportedOperationException();
		}

		@Override
		protected void writeNode() {

			byte[] nodeBytes = new byte[byteCount];
			serializeTreeNodeHead(nodeBytes);
			int nodeDataOffset = HEAD_LENGTH;
			for (int i = 0; i < this.keys.length; i++) {
				if (this.getKey(i) != null) {
					if (indexField.type() == Integer.class) {
						ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(Integer.valueOf(this.getKey(i).toString())), nodeDataOffset);
					} else {
						ByteUtil.setArrayData(nodeBytes, this.getKey(i).toString().getBytes(), nodeDataOffset);
					}
				}
				nodeDataOffset += indexField.length;
			}

			for (int i = 0; i < getValues().length; i++) {

				if (getValue(i) != null) {

					try {
						int currentValueRelativePosition = HEAD_LENGTH + (KEY_COUNT + 1) * indexField.length + 16 * i;
						int currentValuePosition = this.startPosition + currentValueRelativePosition;
						int currentKeyPosition = this.startPosition + HEAD_LENGTH + indexField.length * i;

						byte[] keyBytes = new byte[indexField.length];
						indexFile.seek(currentKeyPosition);
						indexFile.read(keyBytes);
						Object currentKey;
						if (indexField.type() == Integer.class) {
							int anInt = ByteUtil.getIntValue(keyBytes, 0);
							currentKey = anInt == 0 ? null : anInt;
						} else {
							String string = ByteUtil.getStringValue(keyBytes, 0, keyBytes.length).trim();
							currentKey = string == null || string.equals("") ? null : string;
						}
						byte[] valueBytes = new byte[4];
						indexFile.seek(currentValuePosition);
						indexFile.read(valueBytes);
						int currentValuePageNumber = ByteUtil.getIntValue(valueBytes, 0);
						indexFile.seek(currentValuePosition + 4);
						indexFile.read(valueBytes);
						int currentValueRecordNumber = ByteUtil.getIntValue(valueBytes, 0);
						TreeValue currentValue = new TreeValue(currentValuePageNumber, currentValueRecordNumber);

						TreeValue value = (TreeValue) getValue(i);
						// duplicate key overflow
						if (currentKey != null && currentKey.equals(getKey(i))) {
							if (!currentValue.equals(value)) {
								// open new block for link list node
								if (overflowPageOffset == 0 || overflowPageLimit - overflowPageOffset < 12) {
									overflowPageOffset = fpOffset;
									overflowPageLimit = overflowPageOffset + 120;
									fpOffset = fpOffset + 120;
								}
								if (getLinkTail(i) == 0) {
									setNextData(i, overflowPageOffset);
								} else {
									// former tail node link to new tail node
									int formerTailNextOffset = getLinkTail(i) + 8;
									indexFile.seek(formerTailNextOffset);
									indexFile.write(ByteUtil.intToByteArray(overflowPageOffset), 0, 4);
								}
								setTail(i, overflowPageOffset);

								// write former value
								ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(currentValuePageNumber), currentValueRelativePosition);
								nodeDataOffset += 4;
								ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(currentValueRecordNumber), currentValueRelativePosition+4);
								nodeDataOffset += 4;

								// new linked list tail node
								indexFile.seek(overflowPageOffset);
								byte[] overflowBytes = new byte[12];
								ByteUtil.setArrayData(overflowBytes, ByteUtil.intToByteArray(value.getPage()), 0);
								ByteUtil.setArrayData(overflowBytes, ByteUtil.intToByteArray(value.getBytePosition()), 4);
								indexFile.write(overflowBytes, 0, overflowBytes.length);
								overflowPageOffset += overflowBytes.length;
							} else {
								ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(currentValuePageNumber), currentValueRelativePosition);
								nodeDataOffset += 4;
								ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(currentValueRecordNumber), currentValueRelativePosition+4);
								nodeDataOffset += 4;
							}
						} else {
							ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(value.getPage()), nodeDataOffset);
							nodeDataOffset += 4;
							ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(value.getBytePosition()), nodeDataOffset);
							nodeDataOffset += 4;
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
				} else {
					nodeDataOffset += 8;
				}
				ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(getNextLink(i)), nodeDataOffset);
				nodeDataOffset += 4;
				ByteUtil.setArrayData(nodeBytes, ByteUtil.intToByteArray(getLinkTail(i)), nodeDataOffset);
				nodeDataOffset += 4;
			}

			try {
				indexFile.seek(this.startPosition);
				indexFile.write(nodeBytes, 0, nodeBytes.length);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

	public static class TreeValue {

		private int page;

		private int bytePosition;

		public TreeValue(int page, int bytePosition) {
			this.page = page;
			this.bytePosition = bytePosition;
		}

		public int getPage() {
			return page;
		}

		public int getBytePosition() {
			return bytePosition;
		}

		@Override
		public boolean equals(Object o) {
			if (this == o) return true;
			if (o == null || getClass() != o.getClass()) return false;
			TreeValue treeValue = (TreeValue) o;
			return page == treeValue.page &&
					bytePosition == treeValue.bytePosition;
		}

		@Override
		public int hashCode() {
			return Objects.hash(page, bytePosition);
		}

	}
}
