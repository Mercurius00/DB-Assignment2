import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * entity
 */
public class RowData {

    private static DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("MMMM dd, yyyy HH:mm:ss a", Locale.ENGLISH);

    /**
     * id
     */
    private int id;
    /**
     * sensor_id
     */
    private int sensorId;
    /**
     * date_time
     */
    private String dateTime;
    /**
     * year
     */
    private int year;
    /**
     * month
     */
    private int month;
    /**
     * mdate
     */
    private int mdate;
    /**
     * day
     */
    private int day;
    /**
     * time
     */
    private int time;
    /**
     * hourly_counts
     */
    private int hourlyCounts;
    /**
     * sensor_name
     */
    private String sensorName;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSensorId() {
        return sensorId;
    }

    public void setSensorId(int sensorId) {
        this.sensorId = sensorId;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getMdate() {
        return mdate;
    }

    public void setMdate(int mdate) {
        this.mdate = mdate;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }

    public int getDay() {
        return day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getHourlyCounts() {
        return hourlyCounts;
    }

    public void setHourlyCounts(int hourlyCounts) {
        this.hourlyCounts = hourlyCounts;
    }

    public String getSensorName() {
        return sensorName;
    }

    public void setSensorName(String sensorName) {
        this.sensorName = sensorName;
    }

    /**
     * return formatted date time, yyyyMMddhh
     * @return
     */
    public String getDateTimeStr() {
        return dateTimeFormatter.format(LocalDateTime.of(year, month, mdate, time, 0, 0));
    }

    /**
     * calculate the byte length of entity
     * id: 4 bytes
     * dateTimeStr: 10 bytes
     * day: 1 byte
     * year: 4 bytes
     * month: 1 byte
     * mdate: 1 byte
     * time: 1 byte
     * sensorId: 4 bytes
     * hourlyCounts: 4 bytes
     * offset: 4 bytes
     * dateTimeOffset: 4 bytes
     * sensorNameOffset: 4 bytes
     * sdtNameLength: variable length
     * sensorNameLength: variable length
     * @return
     */
    public int length() {
        return 42 + sdtName().getBytes().length + sensorName.getBytes().length;
    }

    /**
     * SDT_NAME index
     * @return
     */
    public String sdtName() {
        return sensorId + "_" + dateTime;
    }

    @Override
    public String toString() {
        return "ID:" + id +
                ", Date_Time:" + getDateTimeStr() +
                ", Year:" + year +
                ", Month:" + Month.of(month).getDisplayName(TextStyle.FULL, Locale.ENGLISH) +
                ", Mdate:" + mdate +
                ", Day:" + DayOfWeek.of(day).getDisplayName(TextStyle.FULL, Locale.ENGLISH) +
                ", Time:" + time +
                ", Sensor_Id:" + sensorId +
                ", sensorName:" + sensorName +
                ", Hourly_Counts:" + hourlyCounts;

    }

    public enum Field {
        /* fixed length fields */
        id(4),
        date_time(10),
        year(4),
        month(4),
        mdate(4),
        day(4),
        time(4),
        sensor_id(4),
        hourly_counts(4),

        /* non-fixed length fields */
        sensor_name(80),
        sdt_name(20);

        // the byte cost of key field in index file
        int length;

        Field(int length) {
            this.length = length;
        }

        public Class type() {
            if (this == date_time || this == sensor_name || this == sdt_name) {
                return String.class;
            } else {
                return Integer.class;
            }
        }
    }
}
