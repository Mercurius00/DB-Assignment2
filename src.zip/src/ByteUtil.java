import java.nio.ByteBuffer;

public class ByteUtil {

    // convert bytes to int value
    public static int getIntValue(byte[] bytes, int position){
        byte[] subArray = new byte[4];
        for(int i = 0; i < subArray.length ; i++){
            subArray[i] = bytes[position + i];
        }
        return ByteBuffer.wrap(subArray).getInt();
    }

    // convert bytes to string value
    public static String getStringValue(byte[] bytes, int position, int length){
        byte[] stringBytes = new byte[length];
        for(int i = 0; i < length ; i++){
            stringBytes[i] = bytes[position + i];
        }
        return new String(stringBytes);
    }

    // convert an int value to bytes
    public static byte[] intToByteArray(int i) {
        byte[] result = new byte[4];
        result[0] = (byte)((i >> 24) & 0xFF);
        result[1] = (byte)((i >> 16) & 0xFF);
        result[2] = (byte)((i >> 8) & 0xFF);
        result[3] = (byte)(i & 0xFF);
        return result;
    }

    // set subArray data into array from the start index of array
    public static void setArrayData(byte[] array, byte[] subArray, int startIndex) {
        for (int i = 0; i < subArray.length; i++) {
            array[startIndex + i] = subArray[i];
        }
    }
}
