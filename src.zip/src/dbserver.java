import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * db support
 * 1. create index: java dbserver createindex [field] [heap file]
 * 2. drop index: java dbserver dropindex [field] [heap file]
 * 3. query data: java dbserver query [condition] [heap file]
 */
public class dbserver {
    public static void main(String[] args) {
        if (args.length != 3) {
            System.err.println("argument error");
            return;
        }

        String command = args[0].trim();
        String heapFileName = args[2].trim();

        if (command.equals("createindex")) {
            createIndex(heapFileName, RowData.Field.valueOf(args[1].trim()));
        } else if (command.equals("dropindex")) {
            dropIndex(heapFileName, RowData.Field.valueOf(args[1].trim()));
        } else if (command.equals("query")) {
            String[] conditionArray = args[1].split("=");
            RowData.Field field = RowData.Field.valueOf(conditionArray[0]);
            Object val;
            if (field.type() == Integer.class) {
                val = Integer.valueOf(conditionArray[1]);
            } else {
                val = conditionArray[1];
            }
            query(field, val, heapFileName);
        }
    }

    private static void query(RowData.Field field, Object val, String heapFileName) {
        String indexFileName = heapFileName + "." + field.name();
        File indexFile = new File(indexFileName);
        if (indexFile.exists()) {
            queryData(field, val, heapFileName);
        } else {
            queryData(field, val, heapFileName);
        }
    }

    public static void queryData(RowData.Field field, Object value, String heapFilePath) {


        boolean hasIndex = false;
        String indexFileName = heapFilePath + "." + field.name();
        File indexFile = new File(indexFileName);
        if (indexFile.exists()) {
            hasIndex = true;
        }

        File heapFile = new File(heapFilePath);


        Map<Integer, List<Integer>> pageRecords = new HashMap<>();
        if (hasIndex) {
            List<BPlusTree.TreeValue> treeValues;
            if (field.type() == Integer.class) {
                BPlusTree<Integer, BPlusTree.TreeValue> bPlusTree = new BPlusTree(heapFilePath, field, "r");
                treeValues = bPlusTree.find(Integer.valueOf(value.toString()));
            } else {
                BPlusTree<String, BPlusTree.TreeValue> bPlusTree = new BPlusTree(heapFilePath, field, "r");
                treeValues = bPlusTree.find((String) value);
            }
            pageRecords = treeValues.stream()
                    .collect(Collectors.groupingBy(BPlusTree.TreeValue::getPage, Collectors.mapping(BPlusTree.TreeValue::getBytePosition, Collectors.toList())));
        }


        FileInputStream fileInputStream = null;
        try {

            long start = System.currentTimeMillis();

            // open heap file
            fileInputStream = new FileInputStream(heapFile);
            String[] heapFileArr = heapFilePath.split("\\.");
            int pageSize = Integer.valueOf(heapFileArr[heapFileArr.length - 1]);

            // initialize byte buffer
            byte[] buffer = new byte[pageSize];

            // total count of records matching the query text
            int totalCount = 0;


            // read the heap file
            int pageNumber = 0;
            while (fileInputStream.read(buffer) >= 0) {
                pageNumber ++;
                if (hasIndex && !pageRecords.containsKey(pageNumber)) {
                    continue;
                }
                int count = 0;
                if (hasIndex) {
                    List<Integer> recordNumbers = hasIndex
                            ? pageRecords.getOrDefault(pageNumber, Collections.emptyList()).stream().sorted(Integer::compareTo).collect(Collectors.toList())
                            : null;
                    // find matched data in current page data
                    count = pageQuery(buffer, recordNumbers, pageSize);
                } else {
                    count = searchCurrentPage(buffer, field, value);
                }
                totalCount += count;
            }

            long end = System.currentTimeMillis();
            System.out.println("find " + totalCount + " records in " + (end - start) + "ms.");

        } catch (Exception e) {
            System.err.println("open heap file failed");
            e.printStackTrace();
        } finally {
            try {
                fileInputStream.close();
            } catch (IOException e) {
                System.err.println("close file input stream failed");
                e.printStackTrace();
            }
        }
    }

    /**
     * query text in page byte data
     * @param buffer
     * @return
     */
    private static int searchCurrentPage(byte[] buffer, RowData.Field field, Object value) {
        int result = 0;

        // page record count
        int recordCount = ByteUtil.getIntValue(buffer, 0);

        // the length of fixed length part of a record
        int recordFixedPartLength = 34;

        for (int i = 0; i < recordCount; i++) {

            // offset position of variable length fields
            RowData rowData = getEntityByOffset(buffer, recordFixedPartLength * i + 4);

            if ((field == RowData.Field.id && ((int) value) == rowData.getId())
                    || (field == RowData.Field.date_time && value.equals(rowData.getDateTime()))
                    || (field == RowData.Field.year && ((int) value) == rowData.getYear())
                    || (field == RowData.Field.month && ((int) value) == rowData.getMonth())
                    || (field == RowData.Field.mdate && ((int) value) == rowData.getMdate())
                    || (field == RowData.Field.day && ((int) value) == rowData.getDay())
                    || (field == RowData.Field.time && ((int) value) == rowData.getTime())
                    || (field == RowData.Field.sensor_id && ((int) value) == rowData.getSensorId())
                    || (field == RowData.Field.hourly_counts && ((int) value) == rowData.getHourlyCounts())
                    || (field == RowData.Field.sensor_name && value.equals(rowData.getSensorName()))
                    || (field == RowData.Field.sdt_name && value.equals(rowData.sdtName()))
            ) {
                System.out.println(rowData);
                result ++;
            }
        }
        return result;
    }

    /**
     * query in current page
     * @param pageData page data
     * @param recordNumbers record index in page
     * @param pageSize
     */
    private static int pageQuery(byte[] pageData, List<Integer> recordNumbers, Integer pageSize) {

        // record count matches query text
        int recordCount = 0;

        // the first record starts from the fourth byte of the page, exclude page record count
//        int recordStartIndex = 4;

        for (Integer recordStartIndex : recordNumbers) {
            if (recordStartIndex + 4 >= pageSize) {
                break;
            }

            // id: 0th~3rd bytes
            int id = ByteUtil.getIntValue(pageData, recordStartIndex);
            if (id == 0) {
                // reach end of page
                break;
            }
            RowData rowData = getEntityByOffset(pageData, recordStartIndex);
            System.out.println(rowData);
            recordCount ++;
        }



        return recordCount;
    }

    private static RowData getEntityByOffset(byte[] pageData, Integer recordStartIndex) {
        int nonFixedPartOffset = ByteUtil.getIntValue(pageData, recordStartIndex + 30);

        RowData rowData = new RowData();

        // convert SDT_NAME_length bytes to int value
        int sdtNameLength = ByteUtil.getIntValue(pageData, nonFixedPartOffset);
        // SDT_NAME string
        String sdtName = ByteUtil.getStringValue(pageData, nonFixedPartOffset + 4, sdtNameLength);
        // sensor_name_length
        int sensorNameLength = ByteUtil.getIntValue(pageData, nonFixedPartOffset + 4 + sdtNameLength);
        // Sensor_Name
        String sensorName = ByteUtil.getStringValue(pageData, nonFixedPartOffset + 8 + sdtNameLength, sensorNameLength);
        rowData.setSensorName(sensorName);


        // year
        int id = ByteUtil.getIntValue(pageData, recordStartIndex);
        rowData.setId(id);
        // datetime
        String datetime = ByteUtil.getStringValue(pageData, recordStartIndex + 4, 10);
        rowData.setDateTime(datetime);
        // day
        rowData.setDay(Byte.valueOf(pageData[recordStartIndex + 14]).intValue());
        // year
        int year = ByteUtil.getIntValue(pageData, recordStartIndex + 15);
        rowData.setYear(year);
        // month
        rowData.setMonth(Byte.valueOf(pageData[recordStartIndex + 19]).intValue());
        // mdate
        rowData.setMdate(Byte.valueOf(pageData[recordStartIndex + 20]).intValue());
        // time
        rowData.setTime(Byte.valueOf(pageData[recordStartIndex + 21]).intValue());
        // sensor_id
        int sensorId = ByteUtil.getIntValue(pageData, recordStartIndex + 22);
        rowData.setSensorId(sensorId);
        // Hourly_Counts
        int hourlyCounts = ByteUtil.getIntValue(pageData, recordStartIndex + 26);
        rowData.setHourlyCounts(hourlyCounts);

        return rowData;
    }

    private static void createIndex(String fileName, RowData.Field field) {
        RandomAccessFile randomAccessFile = null;
        FileChannel fileChannel = null;

        BPlusTree bPlusTree;
        if (field.type() == Integer.class) {
            bPlusTree = new BPlusTree<Integer, BPlusTree.TreeValue>(fileName, field, "w");
        } else {
            bPlusTree = new BPlusTree<String, BPlusTree.TreeValue>(fileName, field, "w");
        }

        try {

            long start = System.currentTimeMillis();

            // open file channel
            randomAccessFile = new RandomAccessFile(fileName, "r");
            fileChannel = randomAccessFile.getChannel();

            // initialize byte buffer
            int pageSize = Integer.valueOf(fileName.replace("heap.", ""));
            ByteBuffer byteBuffer = ByteBuffer.allocate(pageSize);

            int pageNo = 1;
            // read heap file
            while (fileChannel.read(byteBuffer) >= 0) {
                // index page data
                addPageIndex(pageNo, byteBuffer.array(), field, bPlusTree);
                // clear buffer and prepare for next page
                byteBuffer.clear();

                pageNo ++;
            }

            long end = System.currentTimeMillis();
            System.out.println("index created in " + (end - start) + "ms");

        } catch (Exception e) {
            System.err.println("index error");
            e.printStackTrace();
        } finally {
            try {
                fileChannel.close();
                randomAccessFile.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // split page data into records and insert each record into b+ tree
    private static void addPageIndex(int pageNo, byte[] array, RowData.Field column, BPlusTree bPlusTree) {
        // get record count from page header
        int recordCount = ByteUtil.getIntValue(array, 0);

        Integer recordStartPosition = 4;
        /* split page data into records */
        for (int i = 0; i < recordCount; i++) {
            // record data byte array
            Comparable key = getKey(array, column, recordStartPosition);

            // location of record
            BPlusTree.TreeValue treeValue = new BPlusTree.TreeValue(pageNo, recordStartPosition);

            // primary key
            bPlusTree.insert(key, treeValue);

            recordStartPosition += 34;
        }
    }

    // get index field value from record data
    private static Comparable getKey(byte[] array, RowData.Field column, int recordStartPosition) {
        /* variable length fields */
        int variableOffset = ByteUtil.getIntValue(array, recordStartPosition + 30);
        int sdtNameLength = ByteUtil.getIntValue(array, variableOffset);


        switch (column) {
            case id:
                return ByteUtil.getIntValue(array, recordStartPosition);
            case date_time:
                return ByteUtil.getStringValue(array, recordStartPosition + 4, 10);
            case day:
                return Integer.valueOf(array[recordStartPosition + 14]);
            case year:
                return ByteUtil.getIntValue(array, recordStartPosition + 15);
            case month:
                return Integer.valueOf(array[recordStartPosition + 19]);
            case mdate:
                return Integer.valueOf(array[recordStartPosition + 20]);
            case time:
                return Integer.valueOf(array[recordStartPosition + 21]);
            case sensor_id:
                return ByteUtil.getIntValue(array, recordStartPosition + 22);
            case hourly_counts:
                return ByteUtil.getIntValue(array, recordStartPosition + 26);
            case sdt_name:
                return ByteUtil.getStringValue(array, variableOffset + 4, sdtNameLength);
            case sensor_name:
                int sensorNameLength = ByteUtil.getIntValue(array, variableOffset + 4 + sdtNameLength);
                return ByteUtil.getStringValue(array, variableOffset + 8 + sdtNameLength, sensorNameLength);
            default:
                throw new RuntimeException("unrecognized index field");
        }
    }

    private static void dropIndex(String fileName, RowData.Field field) {
        File indexFile = new File(fileName + "." + field.name());
        if (indexFile.exists()) {
            indexFile.delete();
            System.out.println("index droped");
        }
    }
}
